

class Birds():

	def __init__(self):

		self.bird_list = ['sparrow','parrot','peacock']


	def printBirds(self):
		print('Bird list:')
		for bl in self.bird_list:
			print(bl)