
class Mammals():
	def __init__(self):
		self.mammals_list = ['Tiger','cat','dog']


	def printMammals(self):
		print('Mammals list:')
		for ml in self.mammals_list:
			print(ml)
